#include <stdio.h>
#ifndef PIZZA_SIZE
#define PIZZA_SIZE

//Displays pizza size menu
//Allows user to choose and returns choice.
char * sizza()
{
    char choice = 0;         //Holds user choice as ASCII value
    char *pizzaSize;        //Holds corresponding pizza size

    printf("\n[PIZZA SIZES]\n");
    printf("|Personal[1]:  8\"|\n|Small   [2]: 10\"|\n|Medium  [3]: 12\"|\n|Large   [4]: 14\"|\n|X-Large [5]: 16\"|\n|Murica  [6]: 24\"|\n");
    printf("Select your size: ");
    scanf("%s", &choice);

    //Error handling using ASCII values
    if (choice < 49 || choice > 54)
    {
        printf("Error in input\nRestarting size selection\n");
        //Recursion
        sizza();
    }
    else
    {
        //Stores corresponding pizza size and returns it.
        switch(choice)
        {
            case 49:
                pizzaSize = "8\"";
                break;
            case 50:
                pizzaSize = "10\"";
                break;
            case 51:
                pizzaSize = "12\"";
                break;
            case 52:
                pizzaSize = "14\"";
                break;
            case 53:
                pizzaSize = "16\"";
                break;
            case 54:
                pizzaSize = "24\"";
                break;
            default:
                break;
        }
        return pizzaSize;        
    }   
}
#endif